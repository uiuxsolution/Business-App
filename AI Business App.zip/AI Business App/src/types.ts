export type CalculatorType = 
  | 'mortgage'
  | 'loan'
  | 'savings'
  | 'investment'
  | 'retirement';

export interface CalculatorConfig {
  id: CalculatorType;
  title: string;
  description: string;
  icon: string;
}

export interface InputValues {
  // Common
  [key: string]: string;

  // Mortgage Calculator
  homePrice?: string;
  downPayment?: string;
  interestRate?: string;
  loanTerm?: string;
  propertyTax?: string;
  homeInsurance?: string;

  // Loan Calculator
  loanAmount?: string;
  monthlyPayment?: string;

  // Savings Calculator
  initialAmount?: string;
  monthlyDeposit?: string;
  years?: string;

  // Investment Calculator
  initialInvestment?: string;
  monthlyContribution?: string;
  expectedReturn?: string;

  // Retirement Calculator
  currentAge?: string;
  retirementAge?: string;
  currentSavings?: string;
  desiredIncome?: string;
  inflationRate?: string;
}

export interface Results {
  [key: string]: any;
  projections?: any[];
  pieData?: any[];
  schedule?: any[];
  monthlyMortgage?: number;
  monthlyTax?: number;
  monthlyInsurance?: number;
  totalMonthly?: number;
  loanAmount?: number;
  finalBalance?: number;
  yearlyRetirementIncome?: number;
  yearsToRetirement?: number;
  retirementGoal?: number;
}
