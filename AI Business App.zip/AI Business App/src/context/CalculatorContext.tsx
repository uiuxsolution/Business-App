import React, { createContext, useContext, useState, useCallback } from 'react';
import { InputValues, Results, CalculatorType } from '../types';

interface CalculatorContextType {
  activeCalculator: CalculatorType;
  setActiveCalculator: (calculator: CalculatorType) => void;
  inputValues: InputValues;
  setInputValues: (values: InputValues) => void;
  results: Results;
  setResults: (results: Results) => void;
  resetCalculator: () => void;
}

const defaultContext: CalculatorContextType = {
  activeCalculator: 'mortgage',
  setActiveCalculator: () => {},
  inputValues: {},
  setInputValues: () => {},
  results: {},
  setResults: () => {},
  resetCalculator: () => {},
};

const CalculatorContext = createContext<CalculatorContextType>(defaultContext);

export const useCalculator = () => {
  const context = useContext(CalculatorContext);
  if (!context) {
    throw new Error('useCalculator must be used within a CalculatorProvider');
  }
  return context;
};

export const CalculatorProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeCalculator, setActiveCalculatorState] = useState<CalculatorType>('mortgage');
  const [inputValues, setInputValues] = useState<InputValues>({});
  const [results, setResults] = useState<Results>({});

  const resetCalculator = useCallback(() => {
    setInputValues({});
    setResults({});
  }, []);

  const setActiveCalculator = useCallback((calculator: CalculatorType) => {
    setActiveCalculatorState(calculator);
    resetCalculator();
  }, [resetCalculator]);

  return (
    <CalculatorContext.Provider
      value={{
        activeCalculator,
        setActiveCalculator,
        inputValues,
        setInputValues,
        results,
        setResults,
        resetCalculator,
      }}
    >
      {children}
    </CalculatorContext.Provider>
  );
};
