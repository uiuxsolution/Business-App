import { CalculatorConfig, CalculatorType } from './types';

export const calculatorConfigs: CalculatorConfig[] = [
  {
    id: 'mortgage',
    title: 'Mortgage Calculator',
    description: 'Calculate mortgage payments and costs',
    icon: '🏠',
  },
  {
    id: 'loan',
    title: 'Loan Calculator',
    description: 'Calculate loan payments and interest',
    icon: '💰',
  },
  {
    id: 'savings',
    title: 'Savings Calculator',
    description: 'Track your savings growth',
    icon: '💎',
  },
  {
    id: 'investment',
    title: 'Investment Calculator',
    description: 'Project investment returns',
    icon: '📈',
  },
  {
    id: 'retirement',
    title: 'Retirement Calculator',
    description: 'Plan for retirement',
    icon: '🎯',
  },
];