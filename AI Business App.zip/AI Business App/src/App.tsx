import React from 'react';
import { ThemeProvider } from './context/ThemeContext';
import { CalculatorProvider } from './context/CalculatorContext';
import MainContent from './components/MainContent';

function App() {
  return (
    <ThemeProvider>
      <CalculatorProvider>
        <MainContent />
      </CalculatorProvider>
    </ThemeProvider>
  );
}

export default App;
