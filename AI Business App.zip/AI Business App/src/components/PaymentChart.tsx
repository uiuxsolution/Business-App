import React from 'react';

interface Payment {
  month: number;
  balance: number;
  principal: number;
  interest: number;
  payment: number;
}

interface PaymentChartProps {
  schedule: Payment[];
}

export default function PaymentChart({ schedule }: PaymentChartProps) {
  const formatCurrency = (value: number) => 
    new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);

  const maxPayment = Math.max(...schedule.map(item => item.payment));
  
  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow">
        <h3 className="text-lg font-semibold mb-4">Payment Schedule</h3>
        <div className="space-y-2">
          {schedule.slice(0, 12).map((item, index) => (
            <div key={index} className="relative">
              <div className="flex justify-between text-sm mb-1">
                <span>Month {item.month}</span>
                <span>{formatCurrency(item.payment)}</span>
              </div>
              <div className="h-4 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden">
                <div
                  className="h-full bg-blue-500 rounded-full"
                  style={{
                    width: `${(item.payment / maxPayment) * 100}%`,
                  }}
                />
              </div>
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>Principal: {formatCurrency(item.principal)}</span>
                <span>Interest: {formatCurrency(item.interest)}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow">
        <h3 className="text-lg font-semibold mb-4">Payment Breakdown</h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="p-3 bg-blue-50 dark:bg-blue-900 rounded">
            <div className="text-sm text-blue-700 dark:text-blue-200">Principal</div>
            <div className="text-lg font-semibold text-blue-900 dark:text-blue-100">
              {formatCurrency(schedule[0].principal)}
            </div>
          </div>
          <div className="p-3 bg-green-50 dark:bg-green-900 rounded">
            <div className="text-sm text-green-700 dark:text-green-200">Interest</div>
            <div className="text-lg font-semibold text-green-900 dark:text-green-100">
              {formatCurrency(schedule[0].interest)}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
