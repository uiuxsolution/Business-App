import React from 'react';
import { useCalculator } from '../../context/CalculatorContext';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';

interface RetirementTableEntry {
  age: number;
  balance: number;
  totalContributions: number;
  yearlyIncome: number;
  incomeRatio: number;
}

interface Results {
  projections: RetirementTableEntry[];
  finalBalance: number;
  yearlyRetirementIncome: number;
  yearsToRetirement: number;
  retirementGoal: number;
}

interface InputValues {
  currentAge?: string;
  retirementAge?: string;
  currentSavings?: string;
  monthlyContribution?: string;
  expectedReturn?: string;
  inflationRate?: string;
  desiredIncome?: string;
}

export default function RetirementPlanner() {
  const { inputValues, setInputValues, setResults, results } = useCalculator();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setInputValues({ ...inputValues, [name]: value });
  };

  const handleCalculate = () => {
    const currentAge = parseFloat(inputValues.currentAge || '0');
    const retirementAge = parseFloat(inputValues.retirementAge || '0');
    const currentSavings = parseFloat(inputValues.currentSavings || '0');
    const monthlyContribution = parseFloat(inputValues.monthlyContribution || '0');
    const expectedReturn = parseFloat(inputValues.expectedReturn || '0') / 100;
    const inflationRate = parseFloat(inputValues.inflationRate || '0') / 100;
    const desiredIncome = parseFloat(inputValues.desiredIncome || '0');

    // Validate inputs
    if (!currentAge || !retirementAge || !desiredIncome) {
      return; // Don't calculate if essential values are missing
    }

    if (currentAge >= retirementAge) {
      return; // Don't calculate if retirement age is not greater than current age
    }

    const yearsToRetirement = retirementAge - currentAge;
    const projections: RetirementTableEntry[] = [];
    let balance = currentSavings;
    const realReturn = (1 + expectedReturn) / (1 + inflationRate) - 1;

    for (let year = 0; year <= yearsToRetirement; year++) {
      const age = currentAge + year;
      const totalContributions = currentSavings + (monthlyContribution * 12 * year);
      
      if (year > 0) {
        balance = (balance + monthlyContribution * 12) * (1 + realReturn);
      }

      const yearlyIncome = balance * 0.04; // 4% withdrawal rule
      const incomeRatio = yearlyIncome / desiredIncome;

      projections.push({
        age,
        balance: Math.round(balance),
        totalContributions: Math.round(totalContributions),
        yearlyIncome: Math.round(yearlyIncome),
        incomeRatio
      });
    }

    setResults({
      projections,
      finalBalance: Math.round(balance),
      yearlyRetirementIncome: Math.round(balance * 0.04),
      yearsToRetirement,
      retirementGoal: Math.round(desiredIncome * 25) // 25x desired yearly income
    });
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  const formatPercent = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'percent',
      minimumFractionDigits: 0,
      maximumFractionDigits: 1,
    }).format(value);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Personal Information</h3>
          <div className="space-y-2">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Current Age
              </label>
              <input
                type="number"
                name="currentAge"
                placeholder="Enter your current age"
                value={inputValues.currentAge || ''}
                onChange={handleInputChange}
                className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
                min="0"
                max="100"
                step="1"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Retirement Age
              </label>
              <input
                type="number"
                name="retirementAge"
                placeholder="Enter your retirement age"
                value={inputValues.retirementAge || ''}
                onChange={handleInputChange}
                className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
                min="0"
                max="100"
                step="1"
              />
            </div>
          </div>

          <h3 className="text-lg font-semibold mt-6">Financial Information</h3>
          <div className="space-y-2">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Current Retirement Savings
              </label>
              <input
                type="number"
                name="currentSavings"
                placeholder="Enter your current savings"
                value={inputValues.currentSavings || ''}
                onChange={handleInputChange}
                className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
                min="0"
                step="1000"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Monthly Contribution
              </label>
              <input
                type="number"
                name="monthlyContribution"
                placeholder="Enter monthly contribution"
                value={inputValues.monthlyContribution || ''}
                onChange={handleInputChange}
                className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
                min="0"
                step="100"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Desired Yearly Retirement Income
              </label>
              <input
                type="number"
                name="desiredIncome"
                placeholder="Enter desired yearly income"
                value={inputValues.desiredIncome || ''}
                onChange={handleInputChange}
                className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
                min="0"
                step="1000"
              />
            </div>
          </div>

          <h3 className="text-lg font-semibold mt-6">Assumptions</h3>
          <div className="space-y-2">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Expected Annual Return (%)
              </label>
              <input
                type="number"
                name="expectedReturn"
                placeholder="Enter expected return"
                value={inputValues.expectedReturn || ''}
                onChange={handleInputChange}
                className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
                min="0"
                max="100"
                step="0.1"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Expected Inflation Rate (%)
              </label>
              <input
                type="number"
                name="inflationRate"
                placeholder="Enter inflation rate"
                value={inputValues.inflationRate || ''}
                onChange={handleInputChange}
                className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
                min="0"
                max="100"
                step="0.1"
              />
            </div>
          </div>

          <button
            onClick={handleCalculate}
            className="w-full mt-6 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded transition-colors duration-200"
          >
            Calculate Retirement Plan
          </button>
        </div>

        {results && results.projections && results.projections.length > 0 && (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Retirement Summary</h3>
            <div className="grid grid-cols-1 gap-4">
              <div className="p-4 bg-blue-50 dark:bg-blue-900 rounded-lg">
                <p className="text-sm text-blue-600 dark:text-blue-200">Years to Retirement</p>
                <p className="text-2xl font-bold text-blue-700 dark:text-blue-100">
                  {results?.yearsToRetirement || 0} years
                </p>
              </div>
              <div className="p-4 bg-purple-50 dark:bg-purple-900 rounded-lg">
                <p className="text-sm text-purple-600 dark:text-purple-200">Retirement Goal</p>
                <p className="text-2xl font-bold text-purple-700 dark:text-purple-100">
                  {formatCurrency(results?.retirementGoal || 0)}
                </p>
              </div>
              <div className="p-4 bg-green-50 dark:bg-green-900 rounded-lg">
                <p className="text-sm text-green-600 dark:text-green-200">Projected Balance</p>
                <p className="text-2xl font-bold text-green-700 dark:text-green-100">
                  {formatCurrency(results?.finalBalance || 0)}
                </p>
              </div>
              <div className="p-4 bg-yellow-50 dark:bg-yellow-900 rounded-lg">
                <p className="text-sm text-yellow-600 dark:text-yellow-200">Yearly Retirement Income</p>
                <p className="text-2xl font-bold text-yellow-700 dark:text-yellow-100">
                  {formatCurrency(results?.yearlyRetirementIncome || 0)}
                </p>
              </div>
            </div>

            <div className="mt-6">
              <h3 className="text-lg font-semibold mb-4">Retirement Projection</h3>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={results.projections}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="age" label={{ value: 'Age', position: 'bottom' }} />
                  <YAxis
                    tickFormatter={(value) => formatCurrency(value)}
                    label={{ value: 'Balance', angle: -90, position: 'left' }}
                  />
                  <Tooltip
                    formatter={(value: number) => formatCurrency(value)}
                    labelFormatter={(label) => `Age: ${label}`}
                  />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="balance"
                    name="Portfolio Balance"
                    stroke="#2563eb"
                    strokeWidth={2}
                  />
                  <Line
                    type="monotone"
                    dataKey="totalContributions"
                    name="Total Contributions"
                    stroke="#10b981"
                    strokeWidth={2}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="mt-6">
              <h3 className="text-lg font-semibold mb-4">Yearly Breakdown</h3>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                  <thead className="bg-gray-50 dark:bg-gray-800">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Age
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Balance
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Contributions
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Income
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Income Ratio
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-700">
                    {results.projections.map((entry, index) => (
                      <tr 
                        key={entry.age}
                        className={index % 2 === 0 ? 'bg-white dark:bg-gray-900' : 'bg-gray-50 dark:bg-gray-800'}
                      >
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-300">
                          {entry.age}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-300">
                          {formatCurrency(entry.balance)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-300">
                          {formatCurrency(entry.totalContributions)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-300">
                          {formatCurrency(entry.yearlyIncome)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-300">
                          {formatPercent(entry.incomeRatio)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
