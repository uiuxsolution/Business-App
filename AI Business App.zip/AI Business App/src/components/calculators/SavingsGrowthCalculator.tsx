import React from 'react';
import { useCalculator } from '../../context/CalculatorContext';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';

export default function SavingsGrowthCalculator() {
  const { inputValues, setInputValues, setResults, results } = useCalculator();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setInputValues({ ...inputValues, [name]: value });
  };

  const handleCalculate = () => {
    const initialAmount = parseFloat(inputValues.initialAmount || '0');
    const monthlyDeposit = parseFloat(inputValues.monthlyDeposit || '0');
    const interestRate = parseFloat(inputValues.interestRate || '0') / 100;
    const years = parseFloat(inputValues.years || '0');

    if (years > 0) {
      const projections = Array.from({ length: Math.floor(years) + 1 }, (_, year) => {
        const totalDeposits = initialAmount + (monthlyDeposit * 12 * year);
        const balance = calculateCompoundInterest(initialAmount, monthlyDeposit, interestRate, year);
        const interest = balance - totalDeposits;

        return {
          year,
          balance,
          deposits: totalDeposits,
          interest
        };
      });

      setResults({ projections });
    }
  };

  const calculateCompoundInterest = (
    principal: number,
    monthlyContribution: number,
    annualRate: number,
    years: number
  ): number => {
    const monthlyRate = annualRate / 12;
    let balance = principal;

    for (let i = 0; i < years * 12; i++) {
      balance = (balance + monthlyContribution) * (1 + monthlyRate);
    }

    return balance;
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Initial Setup</h3>
          <div className="space-y-2">
            <input
              type="number"
              name="initialAmount"
              placeholder="Initial Amount"
              value={inputValues.initialAmount || ''}
              onChange={handleInputChange}
              className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
              min="0"
              step="100"
            />
            <input
              type="number"
              name="monthlyDeposit"
              placeholder="Monthly Deposit"
              value={inputValues.monthlyDeposit || ''}
              onChange={handleInputChange}
              className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
              min="0"
              step="50"
            />
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Growth Parameters</h3>
          <div className="space-y-2">
            <input
              type="number"
              name="interestRate"
              placeholder="Annual Interest Rate (%)"
              value={inputValues.interestRate || ''}
              onChange={handleInputChange}
              className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
              min="0"
              max="100"
              step="0.1"
            />
            <input
              type="number"
              name="years"
              placeholder="Time Period (Years)"
              value={inputValues.years || ''}
              onChange={handleInputChange}
              className="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600"
              min="1"
              max="50"
              step="1"
            />
          </div>
          <button
            onClick={handleCalculate}
            className="w-full mt-6 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded transition-colors duration-200"
          >
            Calculate Growth
          </button>
        </div>
      </div>

      {results?.projections && results.projections.length > 0 && (
        <div className="mt-8">
          <h3 className="text-lg font-semibold mb-4">Growth Projection</h3>
          <div className="h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={results.projections}
                margin={{
                  top: 5,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis
                  dataKey="year"
                  label={{ value: 'Years', position: 'insideBottom', offset: -5 }}
                />
                <YAxis
                  tickFormatter={(value) => formatCurrency(value)}
                  label={{
                    value: 'Amount',
                    angle: -90,
                    position: 'insideLeft',
                    offset: 10,
                  }}
                />
                <Tooltip
                  formatter={(value: number) => [formatCurrency(value), '']}
                  labelFormatter={(label) => `Year ${label}`}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="balance"
                  name="Total Balance"
                  stroke="#3b82f6"
                  strokeWidth={2}
                />
                <Line
                  type="monotone"
                  dataKey="deposits"
                  name="Total Deposits"
                  stroke="#10b981"
                  strokeWidth={2}
                />
                <Line
                  type="monotone"
                  dataKey="interest"
                  name="Interest Earned"
                  stroke="#8b5cf6"
                  strokeWidth={2}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
    </div>
  );
}
