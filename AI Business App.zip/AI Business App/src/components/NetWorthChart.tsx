import React from 'react';
import { useCalculator } from '../context/CalculatorContext';

const NetWorthChart: React.FC = () => {
  const { results } = useCalculator();

  // For now, we'll create a simple bar representation
  // In a real app, you'd want to use a charting library like Chart.js or Recharts
  const netWorth = results.totalAssets - results.totalLiabilities || 0;
  const height = Math.abs(netWorth) / 1000; // Scale down for visualization

  return (
    <div className="p-4">
      <h3 className="text-lg font-semibold mb-4">Net Worth Trend</h3>
      <div className="relative h-40 bg-gray-100 dark:bg-gray-800 rounded">
        <div
          className={`absolute bottom-0 w-full transition-all duration-500 ${
            netWorth >= 0 ? 'bg-green-500' : 'bg-red-500'
          }`}
          style={{ height: `${Math.min(Math.max(height, 10), 100)}%` }}
        >
          <div className="text-white text-center py-2">
            ${netWorth.toLocaleString()}
          </div>
        </div>
      </div>
    </div>
  );
};

export default NetWorthChart;
