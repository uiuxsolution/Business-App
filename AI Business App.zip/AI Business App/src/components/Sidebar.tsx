import React from 'react';
import { useCalculator } from '../context/CalculatorContext';
import { useTheme } from '../context/ThemeContext';
import { calculatorConfigs } from '../config';

const calculators = [
  {
    id: 'mortgage',
    title: 'Mortgage Calculator',
    description: 'Calculate mortgage payments and costs',
    icon: '🏠'
  },
  {
    id: 'loan',
    title: 'Loan Calculator',
    description: 'Calculate loan payments and interest',
    icon: '💰'
  },
  {
    id: 'savings',
    title: 'Savings Calculator',
    description: 'Track your savings growth',
    icon: '💎'
  },
  {
    id: 'investment',
    title: 'Investment Calculator',
    description: 'Project investment returns',
    icon: '📈'
  },
  {
    id: 'retirement',
    title: 'Retirement Calculator',
    description: 'Plan for retirement',
    icon: '🎯'
  }
];

export default function Sidebar() {
  const { activeCalculator, setActiveCalculator } = useCalculator();
  const { isDarkMode, toggleTheme } = useTheme();

  const handleCalculatorChange = (calculatorId: string) => {
    setActiveCalculator(calculatorId as any);
  };

  return (
    <div className="w-64 h-screen bg-gradient-to-b from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-900 border-r border-gray-200 dark:border-gray-700 flex flex-col shadow-lg">
      {/* Header */}
      <div className="p-4 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 shadow-sm">
        <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
          Finance Pro
        </h1>
        <p className="text-xs text-gray-500 dark:text-gray-400">
          by Ujjwal Kumar
        </p>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-2 space-y-1">
        {calculators.map((calc) => (
          <button
            key={calc.id}
            onClick={() => handleCalculatorChange(calc.id)}
            className={`w-full flex items-center p-2 rounded-lg transition-all duration-200 group ${
              activeCalculator === calc.id
                ? 'bg-blue-500 shadow-md shadow-blue-500/30 scale-[0.98] transform'
                : 'hover:bg-white dark:hover:bg-gray-800 hover:shadow-sm'
            }`}
          >
            <div className={`flex items-center justify-center w-8 h-8 rounded-lg mr-2 transition-colors ${
              activeCalculator === calc.id
                ? 'bg-white/20 text-white'
                : 'bg-gray-100 dark:bg-gray-700 text-gray-500 dark:text-gray-400 group-hover:bg-blue-50 dark:group-hover:bg-gray-600 group-hover:text-blue-500 dark:group-hover:text-blue-400'
            }`}>
              <span className="text-lg" role="img" aria-label={calc.title}>
                {calc.icon}
              </span>
            </div>
            <div className="flex-1 text-left">
              <div className={`text-sm font-medium transition-colors ${
                activeCalculator === calc.id
                  ? 'text-white'
                  : 'text-gray-700 dark:text-gray-300 group-hover:text-blue-500 dark:group-hover:text-blue-400'
              }`}>
                {calc.title}
              </div>
              <div className={`text-xs transition-colors ${
                activeCalculator === calc.id
                  ? 'text-blue-100'
                  : 'text-gray-500 dark:text-gray-400'
              }`}>
                {calc.description}
              </div>
            </div>
          </button>
        ))}
      </nav>

      {/* Footer */}
      <div className="p-2 border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
        <button
          onClick={toggleTheme}
          className="w-full p-2 flex items-center justify-center space-x-2 rounded-lg bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors duration-200"
        >
          <span className="text-base">
            {isDarkMode ? '☀️' : '🌙'}
          </span>
          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
            {isDarkMode ? 'Light Mode' : 'Dark Mode'}
          </span>
        </button>
      </div>
    </div>
  );
}
