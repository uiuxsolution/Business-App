import { CalculatorConfig } from '../types';
import { calculatorConfigs } from '../config';

export default function HomeDashboard() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
      {calculatorConfigs.map((calc) => (
        <div
          key={calc.id}
          className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700"
        >
          <div className="flex items-center gap-3 mb-2">
            <span className="text-2xl">{calc.icon}</span>
            <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
              {calc.title}
            </h2>
          </div>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            {calc.description}
          </p>
        </div>
      ))}
    </div>
  );
}
