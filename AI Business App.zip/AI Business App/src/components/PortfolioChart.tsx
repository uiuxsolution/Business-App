import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Area,
  ComposedChart
} from 'recharts';

interface PortfolioChartProps {
  data: {
    year: number;
    conservative: number;
    moderate: number;
    aggressive: number;
    invested: number;
  }[];
}

const PortfolioChart: React.FC<PortfolioChartProps> = ({ data }) => {
  const formatCurrency = (value: number) => 
    new Intl.NumberFormat('en-US', { 
      style: 'currency', 
      currency: 'USD',
      maximumFractionDigits: 0 
    }).format(value);

  return (
    <div className="w-full h-[400px] bg-white dark:bg-gray-800 rounded-lg shadow p-4">
      <h3 className="text-lg font-semibold mb-4">Portfolio Growth Projection</h3>
      <ResponsiveContainer width="100%" height={320}>
        <ComposedChart
          data={data}
          margin={{
            top: 20,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis
            dataKey="year"
            label={{ value: 'Years', position: 'insideBottom', offset: -5 }}
          />
          <YAxis
            tickFormatter={(value) => `${formatCurrency(value)}`}
            label={{ 
              value: 'Portfolio Value', 
              angle: -90, 
              position: 'insideLeft',
              offset: 10
            }}
          />
          <Tooltip
            formatter={(value: number) => [formatCurrency(value), '']}
            labelFormatter={(year) => `Year ${year}`}
          />
          <Legend />
          <Area
            type="monotone"
            dataKey="invested"
            name="Total Invested"
            fill="#94a3b8"
            stroke="#64748b"
            fillOpacity={0.3}
          />
          <Line
            type="monotone"
            dataKey="conservative"
            name="Conservative (Low Risk)"
            stroke="#0ea5e9"
            strokeWidth={2}
            dot={false}
          />
          <Line
            type="monotone"
            dataKey="moderate"
            name="Moderate (Medium Risk)"
            stroke="#8b5cf6"
            strokeWidth={2}
            dot={false}
          />
          <Line
            type="monotone"
            dataKey="aggressive"
            name="Aggressive (High Risk)"
            stroke="#f43f5e"
            strokeWidth={2}
            dot={false}
          />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
};

export default PortfolioChart;
