import React from 'react';
import {
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  ResponsiveContainer,
  Tooltip
} from 'recharts';

interface RiskAnalysisProps {
  data: {
    conservative: number;
    moderate: number;
    aggressive: number;
  };
}

const RiskAnalysis: React.FC<RiskAnalysisProps> = ({ data }) => {
  const radarData = [
    { metric: 'Potential Return', conservative: 4, moderate: 7, aggressive: 10 },
    { metric: 'Volatility Risk', conservative: 3, moderate: 6, aggressive: 9 },
    { metric: 'Market Risk', conservative: 3, moderate: 6, aggressive: 9 },
    { metric: 'Inflation Risk', conservative: 7, moderate: 5, aggressive: 3 },
    { metric: 'Income Stability', conservative: 9, moderate: 6, aggressive: 3 },
  ];

  const formatPercent = (value: number) => `${value * 10}%`;

  return (
    <div className="w-full h-[500px] bg-white dark:bg-gray-800 rounded-lg shadow p-4">
      <h3 className="text-lg font-semibold mb-4">Risk Analysis</h3>
      
      <ResponsiveContainer width="100%" height={300}>
        <RadarChart data={radarData}>
          <PolarGrid />
          <PolarAngleAxis dataKey="metric" />
          <PolarRadiusAxis tickFormatter={formatPercent} />
          <Tooltip formatter={(value) => `${value * 10}%`} />
          
          <Radar
            name="Conservative"
            dataKey="conservative"
            stroke="#0ea5e9"
            fill="#0ea5e9"
            fillOpacity={0.3}
          />
          <Radar
            name="Moderate"
            dataKey="moderate"
            stroke="#8b5cf6"
            fill="#8b5cf6"
            fillOpacity={0.3}
          />
          <Radar
            name="Aggressive"
            dataKey="aggressive"
            stroke="#f43f5e"
            fill="#f43f5e"
            fillOpacity={0.3}
          />
        </RadarChart>
      </ResponsiveContainer>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
        <div className="p-4 bg-blue-50 dark:bg-blue-900 rounded-lg">
          <h4 className="font-medium text-blue-700 dark:text-blue-200">Conservative</h4>
          <p className="text-sm text-blue-600 dark:text-blue-300 mt-1">
            Lower risk, stable returns, focus on capital preservation
          </p>
        </div>
        <div className="p-4 bg-purple-50 dark:bg-purple-900 rounded-lg">
          <h4 className="font-medium text-purple-700 dark:text-purple-200">Moderate</h4>
          <p className="text-sm text-purple-600 dark:text-purple-300 mt-1">
            Balanced approach, mix of growth and stability
          </p>
        </div>
        <div className="p-4 bg-red-50 dark:bg-red-900 rounded-lg">
          <h4 className="font-medium text-red-700 dark:text-red-200">Aggressive</h4>
          <p className="text-sm text-red-600 dark:text-red-300 mt-1">
            Higher risk, focus on maximum growth potential
          </p>
        </div>
      </div>
    </div>
  );
};

export default RiskAnalysis;
